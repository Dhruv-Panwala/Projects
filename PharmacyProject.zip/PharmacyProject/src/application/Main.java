package application;
	
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;


public class Main extends Application {
	static String username;

	@Override
	public void start(Stage primaryStage) {
		try {
			Parent root =FXMLLoader.load(getClass().getResource("SignUp.fxml"));
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			Image icon= new Image("/Group 1.png");
			
			Random ran= new Random();
			List<String> lines = new ArrayList<>();
	        boolean added = false;
	        try (BufferedReader br = new BufferedReader(new FileReader("@../../medicine-details.csv"))) {
	            String line;
	            boolean flag=false;
	            String []temp = null;
	            while ((line = br.readLine()) != null) {
	            	 temp=line.split(",");
//		            System.out.println(temp[0]);
	            	 if(temp.length>9 && flag==false)
	            	 {
	            		 flag=true;
	            	 }
	            	 if (temp.length >18) {
	            		  
	            	        Double ranprice = ran.nextDouble(2, 100);
	            	        int ranquantity = ran.nextInt(0, 101);
	            	        LocalDate today = LocalDate.now();
	            	        int randomDays = ran.nextInt(5 * 30);
	            	        LocalDate randomDate = today.plus(randomDays, ChronoUnit.DAYS);
	            	        flag=true;
	            	        temp[16] = String.valueOf(ranprice);
	            	        temp[17] = String.valueOf(ranquantity); 
	            	        temp[18] = randomDate.toString(); 
	            	        line=String.join(",",temp);
	            	        lines.add(line);
	            	        flag=true;
	            	  }
	            	  else if(flag==false)
	            	  {
	            		  lines.add(line + "," + "Price"+","+"Quantity"+","+"ExpiryDate");
	            		  flag=true;
	            	  }
	            	  else {
	            		  if(temp[0].equals("Medicine Name"))
	            		  {
	            			  line=String.join(",",line);
	            			  lines.add(line);
	            			  continue;
	            		  }
	            			  
	            		Double ranprice=ran.nextDouble(2,100);
	            		int ranquantity=ran.nextInt(0,101);
	            		 LocalDate today = LocalDate.now();
	            	     int randomDays = ran.nextInt(5 * 30);
	            	     LocalDate randomDate = today.plus(randomDays, ChronoUnit.DAYS);
	            		lines.add(line+","+ranprice+","+ranquantity+","+randomDate);
	            	 }
	            }
	            
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        try (BufferedWriter bw = new BufferedWriter(new FileWriter("@../../medicine-details.csv"))) {
	            for (String line : lines) {
	                bw.write(line);
//	                System.out.println(line);
	                bw.newLine(); // Add new line after each record
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
				
			primaryStage.getIcons().add(icon);
			primaryStage.setTitle("Pharmacy");
			primaryStage.setWidth(1500);
			primaryStage.setHeight(800);
			primaryStage.setResizable(false);
			primaryStage.setScene(scene);
			primaryStage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws IOException {
		launch(args);
		HomeController home =new HomeController();
		home.initialize();
	}
	
}
