package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class CartController {
	
	private ExecutorService executor = Executors.newSingleThreadExecutor();
	@FXML
	private ScrollPane cartDetails;
	@FXML
	private Button buy;
	@FXML
	private Button back;
	private List<String> cartItems;
	private Stage stage;
	private Scene scene;
	private Parent root;
	@FXML
	public void initialize() {
	   
	    FlowPane contentBox = new FlowPane();
	    cartItems = readCartItemsFromFile();
	    // Set horizontal and vertical gaps between panes
	    contentBox.setHgap(10); // Set horizontal gap between Panes
	    contentBox.setVgap(10); // Set vertical gap between Panes
	    
	    if (cartItems == null || cartItems.isEmpty()) {
	        Label itemLabel = new Label("Cart Is Empty");
	        itemLabel.setWrapText(true);
	        itemLabel.setPrefWidth(1500);
	        itemLabel.setFont(new Font(32));
	        contentBox.getChildren().add(itemLabel);
	    } else {
	        for (String itemDetails : cartItems) {
	            String[] itemColumns = itemDetails.split(",");
	            if (itemColumns[0].equals(Main.username)) {
	                Pane pane = createPane(itemColumns);
	                contentBox.getChildren().add(pane); // Add created Pane to FlowPane
	            }
	        }
	    }
	    cartDetails.setContent(contentBox);
	}

	
	private List<String> readCartItemsFromFile(){
		List<String> cartList =new ArrayList<>();
		File cart=new File("addtocart.csv");
        if(cart.exists()==false)
        {
     	   return null;
        }
        
        else {
     	   try {
				Scanner cartread= new Scanner(cart);
				while(cartread.hasNextLine())
				{
					String itemsDetails=cartread.nextLine();
					String[] item=itemsDetails.split(",");
					if(item[0].equals(Main.username))
					{
						cartList.add(itemsDetails);
					}
				}
				cartread.close();
			} catch (IOException e) {
				e.printStackTrace();
			} 
        }
        return cartList;
	}
	
	 private Pane createPane(String []details) {
	    	Pane pane = new Pane();
	        
	    	try {
	    	pane.setPrefSize(1450,200);
	        pane.setStyle("-fx-background-color: #EEEEEE;-fx-border-color: black; -fx-border-width: 1px;");
	        
	        DropShadow dropShadow = new DropShadow();
	        URL imageUrl = new URL("https://onemg.gumlet.io/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto," + details[5]);

	        executor.submit(() -> {
	            try {
	                InputStream stream = imageUrl.openStream();
	                Image image = new Image(stream);
	                stream.close();

	                Platform.runLater(() -> {
	                    ImageView imageView = new ImageView(image);
	                    imageView.setFitWidth(100);
	                    imageView.setFitHeight(100);
	                    imageView.setLayoutX(15);
	                    imageView.setLayoutY(30);
	                    pane.getChildren().add(imageView);
	                });
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        });
					int xlayout=120;
					int ylayout=80;
			        for (int i = 0; i <details.length; i++) {
			        	if(i==1 || i==2)
			        	{
			        		
			                Label label = new Label(details[i]);
			                label.setWrapText(true); 
			                label.setLayoutX(xlayout);
			                label.setLayoutY(ylayout);
			                label.setPrefWidth(290);
//			                label.setAlignment(Pos.CENTER);
			                ylayout+=10;
//			                xlayout-=20;
			                pane.getChildren().add(label);
			        	}
			        	else if(i==4)
			        	{

			                Label label = new Label("£"+String.format("%.2f", Double.parseDouble(details[4])));
			                label.setWrapText(true); 
			                label.setLayoutX(xlayout+350);
			                label.setLayoutY(ylayout-25);
			                label.setStyle("-fx-TextFill:blue;-fx-font-size:14px;-fx-font-weight:Bold;-fx-background-radius: 10px;");
			                xlayout-=20;
			                pane.getChildren().add(label);
			        	}
			        	else if(i==3)
			        	{
			        		  Label label = new Label(details[3]);
				                label.setWrapText(true); 
				                label.setLayoutX(xlayout+450);
				                label.setLayoutY(ylayout-25);
				                xlayout-=20;
				                pane.getChildren().add(label);
			        	}
			        
			        }
			        Button remove = new Button("Remove");
			        remove.setStyle("-fx-text-fill: white; -fx-background-color: #156543;");
			        remove.setLayoutX(xlayout+1200);
			        remove.setLayoutY(ylayout-25);
//			        addtocart.setPrefWidth(145);
			        
			        remove.setOnAction(event -> {
			        	 List<String[]> rows = new ArrayList<>();
			             String line;
			             
			             // Read the CSV file and store its contents in a list of arrays
			             try (BufferedReader br = new BufferedReader(new FileReader("addtocart.csv"))) {
			                 while ((line = br.readLine()) != null) {
			                     String[] row = line.split(",");
			                     // Check if the first column (name) matches the name to delete
			                     if (row.length >0  && row[0].equals(Main.username) && row[1].equals(details[1])) {
			                         continue; 
			                     }
			                     rows.add(row); 
			                 }
			             } catch (IOException e) {
			                 e.printStackTrace();
			                 return;
			             }
			             
			             try (BufferedWriter bw = new BufferedWriter(new FileWriter("addtocart.csv"))) {
			                 for (String[] row : rows) {
			                     bw.write(String.join(",", row));
			                     bw.newLine();
			                 }
			             } catch (IOException e) {
			                 e.printStackTrace();
			             }
			             initialize();
			        });
			        
		        	pane.getChildren().add(remove);
		        	 
	    	} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	return pane;   
	    }
	 @FXML
	private void buy(ActionEvent Event) throws IOException, ParseException
	{
		File f=new File("History.csv");
		if(!f.exists())
		{
			BufferedWriter writer = new BufferedWriter(new FileWriter("History.csv"));
			  writer.write("UserName"+","+"MedicineName"+","+"Manufacturer"+","+"Quantity"+","+"Price"+","+"URL"+","+"Expiry Date"+","+"BatchNumber"+","+"PurchaseDate");
	          writer.newLine();
	          writer.close();
		}
			if(cartItems == null || cartItems.isEmpty())
			{
				try {
					throw new CustomException("Cart is Empty");
				}catch(CustomException e)
				{
					 ExceptionHandler.handleException(e);
				}
			}
			else {	
				List<String> old = new ArrayList<>();
				try(BufferedReader read = new BufferedReader(new FileReader("History.csv")))
				{
					String line;
					while((line=read.readLine())!=null)
					{
						old.add(line);
					}
				}
				boolean isExpired = false;
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
				Date checkToday = new Date();

				try {
				    for (String temp : cartItems) {
				        String[] checking = temp.split(",");
				        
				        String dateString = checking[6].trim();
				        System.out.println("Date String: " + dateString); 

				        Date checkDate = sdf.parse(dateString);
				        System.out.println("Parsed Date: " + sdf.format(checkDate)); 
				        if (checkDate.before(checkToday)) {
				            isExpired = true;
				            throw new CustomException(checking[1] + " is not available. Please remove it from the cart.");
				        }
				    }
				} catch (ParseException e) {
				    // Handle parsing exceptions
				    e.printStackTrace();
				} catch (CustomException event) {
				    // Handle CustomException
				    ExceptionHandler.handleException(event);
				}

				
		  if(isExpired==false)
		  {
			  try (BufferedWriter writer = new BufferedWriter(new FileWriter("History.csv"))) {
//		            writer.write("UserNAme"+","+"MedicineName"+","+"Manufacturer"+","+"Quantity"+","+"Price"+","+"URL"+","+"BatchNumber"+","+"PurchaseDate");
//		            writer.newLine();
		                for (String row : old) {
		                    writer.write(row);
		                    writer.newLine();
		                }
		            
		        
		            String batchNumber = generateUniqueBatchNumber("History.csv");
				  	LocalDate today = LocalDate.now();
				    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				    String Date=today.format(formatter);
				  	for (String line : cartItems) {
				  		String[]temp=line.split(",");
				  		if(temp[0].equals(Main.username))
				  		{
				  			writer.write(line+","+batchNumber+","+Date);
		                	writer.newLine();
				  		}
		            }
				  	throw new CustomException("Your Batch Number is"+batchNumber);
				  	
		        } catch (IOException e) {
		            System.err.println("Error writing to CSV file: " + e.getMessage());
		        }catch (CustomException e)
			  	{
		        	ExceptionHandler.handleException(e);
			  	}
		  	
			   List<String> linesToKeep = new ArrayList<>();
			   String inputFile = "addtocart.csv";
		        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
		            String line;
		            while ((line = reader.readLine()) != null) {
		                String[] columns = line.split(",");
		                // Check if column 1 matches the username
		                if (!(columns[0].equals(Main.username))) {
		                    linesToKeep.add(line);
		                }
		            }
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
		        try (BufferedWriter writer = new BufferedWriter(new FileWriter("addtocart.csv"))) {
		            for (String line : linesToKeep) {
		                writer.write(line);
		                writer.newLine();
		            }
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
		  	}

		}
		        initialize();
	}
	 public static String generateUniqueBatchNumber(String inputFile) {
	        String newBatchNumber = generateBatchNumber();
	        while (batchNumberExists(newBatchNumber, inputFile)) {
	            newBatchNumber = generateBatchNumber();
	        }
	        return newBatchNumber;
	    }
	 public static String generateBatchNumber() {
	        Random random = new Random();
	        int batchNumber = random.nextInt(900000) + 100000;
	        return String.valueOf(batchNumber);
	    }
	 
	 public static boolean batchNumberExists(String batchNumber, String inputFile) {
	        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                String[] columns = line.split(",");
	                if (columns.length > 0 && columns[6].equals(batchNumber)) {
	                    return true;
	                }
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return false;
	    }
	 
	@FXML
	private void back(ActionEvent Event) throws IOException
	{
		root =FXMLLoader.load(getClass().getResource("Main.fxml"));
		stage = (Stage) ((Node) Event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
}
	

