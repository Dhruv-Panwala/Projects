package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LogINController {
	@FXML
	private TextField userName;
	@FXML
	private PasswordField PasswordText;
	private Button logIN;
	private Parent root;
	private Stage stage;
	private Scene scene;
	@FXML
	private Button signUP;
	
	
	public void signUP(ActionEvent event) throws IOException 
	{
		root =FXMLLoader.load(getClass().getResource("SignUp.fxml"));
		
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void LogIN(ActionEvent event) throws IOException
	{
		try {
			if(userName.getText().equals("") || PasswordText.getText().equals(""))
			{
					throw new CustomException("Fields Cannot be Empty");
			}
			else {
				 FileReader fr = new FileReader("userDetails.csv");
				 
				
				 	BufferedReader br = new BufferedReader(fr);
				    String line;
				    while ((line = br.readLine()) != null) {
				        String[] part = line.split(",");
				        if (userName.getText().equals(part[1]) && PasswordText.getText().equals(part[2])&& part[3].equalsIgnoreCase("FALSE")) {
				        	root =FXMLLoader.load(getClass().getResource("Main.fxml"));
							stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
							scene = new Scene(root);
							stage.setScene(scene);
							stage.show();
				        }else if (userName.getText().equals(part[1]) && PasswordText.getText().equals(part[2])&& part[3].equalsIgnoreCase("TRUE")) {
				        	root =FXMLLoader.load(getClass().getResource("PharmacyManagement.fxml"));
							stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
							scene = new Scene(root);
							stage.setScene(scene);
							stage.show();
				        }
				        else if (userName.getText().equals(part[1]) && !PasswordText.getText().equals(part[2])) {
				        	br.close();
				        	throw new CustomException("Password Does Not Match");
				        } 
				    }
				    br.close();
				   
				 	
			}
			Main.username=userName.getText();
		}catch (CustomException e) {
            ExceptionHandler.handleException(e);
        }
		
	}
	
}
