package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class HomeController {
	@FXML
	private TextField SearchTextField;
	@FXML
	private Button history;
	private ExecutorService executor = Executors.newSingleThreadExecutor();
	private Button Cart;
	private Stage stage;
	private Scene scene;
	private TextField rating;
	private Parent root;
	@FXML
	private ScrollPane medicineDetails;
	private String line;
	private String[] values;
	@FXML
	private Button search;
	private Button cancel;
	int count;
	  private final int itemsPerPage = 13;

	    public void search() {
	    	count=0;
	        String searchText = SearchTextField.getText().toLowerCase();
	        List<String[]> searchOutput = new ArrayList<>();
	        File file = new File("@../../medicine-details.csv");
	        try (Scanner scanner = new Scanner(file)) {
	            while (scanner.hasNextLine()) {
	                String line = scanner.nextLine();
	                String[] values = line.split(",");
	                int flag = 1;
	                for (String value : values) {
	                    String input = searchText;
	                    String patternString = input + "+";
	                    Pattern pattern = Pattern.compile(patternString);
	                    Matcher matcher = pattern.matcher(value.toLowerCase());
	                    if(!patternString.equals("+"))
	                    {	
	                    	while (matcher.find()) {
	                        	searchOutput.add(values);
	                        	flag = 0;
	                    	}
	                    }
	                }
	            }

	            displaySearchResults(searchOutput);
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        }
	    }

	    // Display search results in FlowPane
	    private void displaySearchResults(List<String[]> searchOutput) {
	        FlowPane flowPane = new FlowPane();
	        flowPane.setPrefWrapLength(1255);
	        flowPane.setHgap(20);
	        flowPane.setVgap(10);

	        int startIndex = count;
	        int endIndex = count+11;

	        for (int i = startIndex; i < endIndex && i<searchOutput.size(); i++) {
	            String[] temp = searchOutput.get(i);
	            Pane pane = createPane(temp);
	            flowPane.getChildren().add(pane);   
	        }

	        count = endIndex; 
	        if (count < searchOutput.size()) {
	            Button loadMoreButton = createLoadMoreButton();
	            flowPane.getChildren().add(loadMoreButton);
	            
	            Button cancel= createcancelButton();
	            flowPane.getChildren().add(cancel);
	        }
	        
	        medicineDetails.setContent(flowPane);
	    }
	    private Button createcancelButton() {
	    	Button loadMoreButton = new Button("X");
	        loadMoreButton.setStyle("-fx-text-fill: white; -fx-background-color: #156543;");
	        loadMoreButton.setOnAction(event -> initialize());
	        return loadMoreButton;
	    }

	    // Create Load More button
	    private Button createLoadMoreButton() {
	        Button loadMoreButton = new Button("Load More");
	        loadMoreButton.setStyle("-fx-text-fill: white; -fx-background-color: #156543;");
	        loadMoreButton.setOnAction(event -> {loadMoreResults();});
	        return loadMoreButton;
	    }

	    // Load more search results
	    private void loadMoreResults() {
	        FlowPane flowPane = (FlowPane) medicineDetails.getContent();
	        flowPane.getChildren().removeIf(node -> node instanceof Button);

	        List<String[]> searchOutput = new ArrayList<>();
	        File file = new File("@../../medicine-details.csv");
	        flowPane.getChildren().removeIf(node -> node instanceof Button);
	        try (Scanner scanner = new Scanner(file)) {
	            while (scanner.hasNextLine()) {
	                String line = scanner.nextLine();
	                String[] values = line.split(",");
	                int flag = 1;
	                for (String value : values) {
	                    String input = SearchTextField.getText().toLowerCase();
	                    String patternString = input + "+";
	                    Pattern pattern = Pattern.compile(patternString);
	                    Matcher matcher = pattern.matcher(value.toLowerCase());
	                    while (matcher.find() && Integer.parseInt(values[17]) > 0) {
	                        searchOutput.add(values);
	                        flag = 0;
	                    }
	                    if (flag == 0) {
	                        break;
	                    }
	                }
	            }
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        }
	        int startIndex = count;
	        int endIndex = Math.min(count + 10, searchOutput.size());

	        for (int i = startIndex; i < endIndex; i++) {
	            String[] temp = searchOutput.get(i);
	            Pane pane = createPane(temp);
	            flowPane.getChildren().add(pane);
	        }
	        count = endIndex; 
	        if (count < searchOutput.size()) {
	            Button loadMoreButton = createLoadMoreButton();
	            flowPane.getChildren().add(loadMoreButton);
	            Button cancel = createcancelButton();
	            flowPane.getChildren().add(cancel);
	        }
	    }
	public void history(ActionEvent e) throws IOException 
	{
		root =FXMLLoader.load(getClass().getResource("history.fxml"));
		stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public void cart(ActionEvent e) throws IOException 
	{
		root =FXMLLoader.load(getClass().getResource("cart.fxml"));
		stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	
	}
	public void account(ActionEvent e) throws IOException 
	{
		root =FXMLLoader.load(getClass().getResource("cart.fxml"));
		stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	
	}
	
	public void initialize() {
	    FlowPane flowPane = new FlowPane();
	    flowPane.setPrefWrapLength(1255); 
	    flowPane.setHgap(20);
	    flowPane.setVgap(10);
	    this.count=0;
	    loadPanes(flowPane, 11);
	    Button loadMoreButton = createLoadMoreButton(flowPane);
	    flowPane.getChildren().add(loadMoreButton);
	    medicineDetails.setContent(flowPane);
	}
	private Button createLoadMoreButton(FlowPane flowPane) {
		
	    Button loadMoreButton = new Button("Load More");
	    loadMoreButton.setStyle("-fx-text-fill: white; -fx-background-color: #156543;");
	    loadMoreButton.setOnAction(event -> {	
	    	loadMorePanes(flowPane, 10);
	    	medicineDetails.setVvalue(1.0);
	    });
	    return loadMoreButton;
	}

	private void loadMorePanes(FlowPane flowPane, int count) {
	    flowPane.getChildren().removeIf(node -> node instanceof Button);

	    
	    loadPanes(flowPane, count);

	    Button loadMoreButton = createLoadMoreButton(flowPane);
	    flowPane.getChildren().add(loadMoreButton);

	  
	}	
	
	private void loadPanes(FlowPane flowPane, int count) {
	    File file = new File("@../../medicine-details.csv");
	    try (Scanner scanner = new Scanner(file)) {
	        scanner.nextLine();
	        int loadedCount = 0;
	        int temp=this.count;
//	        System.out.println(temp);
	        while (scanner.hasNextLine() && loadedCount < count + temp) {
	            if (temp > 0) {
	                scanner.nextLine();
	                temp--;
	                continue;
	            }
	            String line = scanner.nextLine();
	            String[] values = line.split(",");
	            Pane pane = createPane(values);
	            flowPane.getChildren().add(pane);
	            loadedCount++;    
	        }
	        this.count+=loadedCount;
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    }
	}


    private Pane createPane(String []details) {
    	Pane pane = new Pane();
        
    	try {
    	pane.setPrefSize(290,350);
        pane.setStyle("-fx-background-color: #EEEEEE;");
        pane.setOnMouseClicked(event->{
        	try {
        		FXMLLoader loader = new FXMLLoader(getClass().getResource("MedicineDetails.fxml"));
                Parent root = loader.load();
                MedicineDetailsController controller = loader.getController();
                controller.initialize(details);

                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
        	} catch (IOException e) {
				e.printStackTrace();
			}
        });
        DropShadow dropShadow = new DropShadow();
        URL imageUrl = new URL("https://onemg.gumlet.io/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,"+details[11]);

        executor.submit(() -> {
            try {
                InputStream stream = imageUrl.openStream();
                Image image = new Image(stream);
                stream.close();

                Platform.runLater(() -> {
                    ImageView imageView = new ImageView(image);
                    imageView.setFitWidth(150);
                    imageView.setFitHeight(200);
                    imageView.setLayoutX(65);
                    imageView.setLayoutY(15);
                    pane.getChildren().add(imageView);
                });
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        
				int xlayout=80;
				int ylayout=250;
		        for (int i = 0; i <details.length; i++) {
		        	if(i==0 || i==12)
		        	{
		        		
		                Label label = new Label(details[i]);
		                label.setWrapText(true); 
//		                label.setLayoutX(xlayout);
		                label.setLayoutY(ylayout);
		                label.setPrefWidth(290);
		                label.setAlignment(Pos.CENTER);
		                ylayout+=10;
		                xlayout-=20;
		                pane.getChildren().add(label);
		        	}
		        	else if(i==16)
		        	{

		                Label label = new Label("£"+String.format("%.2f", Double.parseDouble(details[16])));
		                label.setWrapText(true); 
//		                label.setLayoutX(xlayout);
		                label.setLayoutY(ylayout+5);
		                label.setPrefWidth(290);
		                label.setAlignment(Pos.CENTER);
		                label.setStyle("-fx-TextFill:blue;-fx-font-size:14px;-fx-font-weight:Bold;");
		                ylayout+=10;
		                xlayout-=20;
		                pane.getChildren().add(label);
		        	}
		        
		        }
		        Button addtocart = new Button("Add To Cart");
	        	addtocart.setStyle("-fx-text-fill: white; -fx-background-color: #156543;");
		        addtocart.setLayoutY(ylayout+20);
		        addtocart.setLayoutX(xlayout+55);
		        addtocart.setPrefWidth(145);
		        
		        addtocart.setOnAction(event -> {
//		        System.out.println(details[17]);
		        String quan="1";
		        if(Integer.parseInt(details[17])>0)
		        {

		           File cart=new File("addtocart.csv");
		           if(cart.exists()==false)
		           {
		        	   try {
						CSVWriter.createCSV("addtocart.csv",Main.username,details[0],details[12], String.format("%.2f", Double.parseDouble(details[16])),details[11],details[18]);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		           }
		           else {
		        	   try {
						Scanner cartread= new Scanner(cart);
						boolean exists=false;
						while(cartread.hasNextLine())
						{
							String itemsDetails=cartread.nextLine();
							String[] item=itemsDetails.split(",");
							if(item[0].equals(Main.username) && item[1].equals(details[0]))
							{
								quan=item[3];
								exists=true;
							}
						}
						if(exists==false)
							CSVWriter.addDetails("addtocart.csv",Main.username,details[0],details[12],String.format("%.2f", Double.parseDouble(details[16])),details[11],details[18]);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		           }
		           addtocart.setVisible(false);
		           TextField quantity = new TextField(quan);
		           quantity.setDisable(true);
		           quantity.setLayoutY(300);
			       quantity.setLayoutX(80);
			       quantity.prefWidth(100);
			       quantity.setAlignment(Pos.CENTER);
			       quantity.setStyle("-fx-background-color:white;-fx-text-fill:Black;");
		           Button add= new Button("+");
		           add.setLayoutY(300);
		           add.setLayoutX(200);
		           add.setStyle("-fx-background-color:#0A452C;-fx-text-fill:White;");
				      
		           Button remove= new Button("-");
		           remove.setLayoutY(300);
		           remove.setLayoutX(80);
		           remove.setStyle("-fx-background-color:#0A452C;-fx-text-fill:White;");
				      
//		           add.prefWidth();
		           
		           add.setOnAction(addevent->{
		        	   List<String[]> lines = new ArrayList<>();
		        	   try {
						BufferedReader br = new BufferedReader(new FileReader("addtocart.csv"));
						String line;
			            while ((line = br.readLine()) != null) {
			                String[] data = line.split(",");
			                lines.add(data);
//			                System.out.println(line);
			            }
//			            System.out.println(details[0]);
			            for (String[] i : lines) {
			            	if(i[1].equals(details[0]) && i[0].equals(i[0]))
			            	{
			            		i[3]= String.valueOf(Integer.parseInt(i[3])+1);
			            		quantity.setText(i[3]);
			            	}
			            }
			            
			            writeCSV(lines);
			            
			        } catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		        	   
		           });
		           
		           remove.setOnAction(addevent->{
		        	   List<String[]> lines = new ArrayList<>();
		        	   try {
						BufferedReader br = new BufferedReader(new FileReader("addtocart.csv"));
						String line;
						while ((line = br.readLine()) != null) {
			                String[] data = line.split(",");
			                lines.add(data);
			            }
						int printing=1;
//			            System.out.println(details[0]);
			            for (String[] i : lines) {
			            	if(i[1].equals(details[0]) && i[0].equals(i[0]))
			            	{
//			            		System.out.println(i);
			            		i[3]= String.valueOf(Integer.parseInt(i[3])-1);
			            		quantity.setText(i[3]);
			            		if(Integer.parseInt(i[3])==0)
			            		{
			            			add.setVisible(false);
			            			remove.setVisible(false);
			            			quantity.setVisible(false);
			            			addtocart.setVisible(true);
			            			CSVWriter.removeDetails("addtocart.csv", details[0], details);
			            			printing=0;
			            		}
			            	}
			            }
			            if(printing==1)
			            writeCSV(lines);
			            
			        } catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		        	   
		           });
		           pane.getChildren().add(quantity);
		           pane.getChildren().add(add);
		           pane.getChildren().add(remove);
		           
		        }});
	        	pane.getChildren().add(addtocart);
	        	 
    	} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return pane;   
    }
    
   protected static void writeCSV(List<String[]> lines )
    {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("addtocart.csv"))) {
//        	System.out.println(2);
        	for (String[] line : lines) {
                for (int i = 0; i < line.length; i++) {
                    bw.write(line[i]);
                    if (i < line.length - 1) {
                        bw.write(","); 
                    }
                }
                bw.newLine(); 
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}

//Link Start at 4 from index 0--> 11
