package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class historyController {
	private ExecutorService executor = Executors.newSingleThreadExecutor();
	@FXML
	private TextField SearchTextField;
	@FXML
	private Button back;
	@FXML
	private ScrollPane historyDetails;
	private Stage stage;
	private Scene scene;
	private Parent root;
	
	@FXML
	private void search(ActionEvent event) throws IOException
	{
		FlowPane flowPane= new FlowPane();
		String textfield = SearchTextField.getText();
		List<String> batch=new ArrayList<>();
		BufferedReader read = new BufferedReader(new FileReader("History.csv"));
		
		try{
			if(textfield==null ||textfield.isEmpty())
			{
				throw new CustomException("Enter Batch Number");
			}
			else{
				String line;
				while((line=read.readLine())!=null)
				{
					String []temp = line.split(",");
					if(temp[7].equals(textfield) && temp[0].equals(Main.username))
					{
						batch.add(line);
					}
				}
				for(String i:batch)
				{
					String []temp = i.split(",");
					Pane pane =CreateNewPane(temp);
					flowPane.getChildren().add(pane);
				}
				historyDetails.setContent(flowPane);
			}
		}catch (CustomException e) {
			
		}
		
	}
	private Pane CreateNewPane(String []details)
	{
		Pane pane = new Pane();
        
    	try {
    	pane.setPrefSize(1450,200);
        pane.setStyle("-fx-background-color: #EEEEEE;-fx-border-color: black; -fx-border-width: 1px;");
        
        DropShadow dropShadow = new DropShadow();
        URL imageUrl = new URL("https://onemg.gumlet.io/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto," + details[5]);

        executor.submit(() -> {
            try {
                InputStream stream = imageUrl.openStream();
                Image image = new Image(stream);
                stream.close();

                Platform.runLater(() -> {
                    ImageView imageView = new ImageView(image);
                    imageView.setFitWidth(100);
                    imageView.setFitHeight(100);
                    imageView.setLayoutX(15);
                    imageView.setLayoutY(30);
                    pane.getChildren().add(imageView);
                });
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
				int xlayout=120;
				int ylayout=80;
		        for (int i = 0; i <details.length; i++) {
		        	if(i==1 || i==2)
		        	{
		        		
		                Label label = new Label(details[i]);
		                label.setWrapText(true); 
		                label.setLayoutX(xlayout);
		                label.setLayoutY(ylayout);
		                label.setPrefWidth(290);
//		                label.setAlignment(Pos.CENTER);
		                ylayout+=10;
//		                xlayout-=20;
		                pane.getChildren().add(label);
		        	}
		        	else if(i==4)
		        	{

		                Label label = new Label("£"+String.format("%.2f", Double.parseDouble(details[4])));
		                label.setWrapText(true); 
		                label.setLayoutX(xlayout+950);
		                label.setLayoutY(ylayout-25);
		                label.setStyle("-fx-TextFill:blue;-fx-font-size:14px;-fx-font-weight:Bold;-fx-background-radius: 10px;");
		                xlayout-=20;
		                pane.getChildren().add(label);
		        	}
		        	else if(i==3)
		        	{
		        		  Label label = new Label(details[3]);
			                label.setWrapText(true); 
			                label.setLayoutX(xlayout+850);
			                label.setLayoutY(ylayout-25);
			                xlayout-=20;
			                pane.getChildren().add(label);
		        	}
		        	else if(i==7)
		        	{
		        		Label label = new Label(details[7]);
		                label.setWrapText(true); 
		                label.setLayoutX(xlayout+750);
		                label.setLayoutY(ylayout-25);
		                xlayout-=20;
		                pane.getChildren().add(label);
		        	}
		        
		        }
		       
    	} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return pane;   
    }
	@FXML
	private void back(ActionEvent Event) throws IOException
	{
		root =FXMLLoader.load(getClass().getResource("Main.fxml"));
		stage = (Stage) ((Node) Event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
}
