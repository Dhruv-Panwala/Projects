package application;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class CSVWriter {

	  static void createCSV(String filePath, String userName,String medicineName, String Manufacturer,String price,String url,String expiryDate) throws IOException {
//	        String filePath = "example.csv";
	        
	        try (PrintWriter writer = new PrintWriter(new FileWriter(filePath, true))) {
	        	
	    		writer.append("UserName");
		        writer.append(",");
		        writer.append("MedicineName");
		        writer.append(",");
		        writer.append("Manufacturer");
		        writer.append(",");
		        writer.append("Quantity");
		        writer.append(",");
		        writer.append("price");
		        writer.append(",");
		        writer.append("URL");
		        writer.append(",");
		        writer.append("ExpiryDate");
		        writer.append("\n");		        
	          
//	            addDetails(filePath,userName,medicineName,Manufacturer,price);
	            
	            System.out.println("CSV file was created successfully.");
	        } catch (IOException e) {
	            System.out.println("An error occurred:");
	            e.printStackTrace();
	        }
	        addDetails(filePath,userName,medicineName,Manufacturer,price,url,expiryDate);
	           
	    }

	    // Helper method to add details to the CSV
	    static void addDetails(String filePath, String userName,String MedicineName, String Manufacturer,String price,String url,String expiryDate) throws IOException {
	    	try (PrintWriter writer = new PrintWriter(new FileWriter(filePath, true))) {
	    		
	    		writer.append(userName);
		        writer.append(",");
		        writer.append(MedicineName);
		        writer.append(",");
		        writer.append(Manufacturer);
		        writer.append(",");
		        writer.append("1");
		        writer.append(",");
		        writer.append(price);
		        writer.append(",");
		        writer.append(url);
		        writer.append(",");
		        writer.append(expiryDate);
	    		writer.append("\n");		        
		    }
	    }
	    
	    static void removeDetails(String filePath, String nameToRemove,String []details) {
	    	List<String> lines = new ArrayList<>();
	    	System.out.println(3);
	        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
	            String line;
	            while ((line = br.readLine()) != null) {
	            	System.out.println(line);
	                String[] parts = line.split(","); // Assuming comma-separated values
	                if (parts[0].equals("Dhruv") && parts[1].equals(details[0])) {
	                	continue;    
	                }else {
	                	lines.add(line);
	                }
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }

	        try (BufferedWriter bw = new BufferedWriter(new FileWriter("addtocart.csv"))) {
	            for (String line : lines) {
	                for (int i = 0; i < line.length(); i++) {
	                    bw.write(line);
	                    
	                    if (i < line.length() - 1) {
	                    	bw.write(","); // Add comma between values
	                    }
	                    break;
	                }
	                bw.newLine();
	                
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }}
}
