package application;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ExceptionHandler {
    public static void handleException(CustomException e) {
    	Stage stage = new Stage();
        Label label = new Label(e.getMessage());
        label.setLayoutX(130);
        label.setLayoutY(100);
        Button okButton = new Button("OK");
        okButton.setLayoutX(140);
        okButton.setLayoutY(150);
        okButton.setOnAction(event -> stage.close());
        VBox root = new VBox(10); // Spacing between label and button
        root.setAlignment(Pos.CENTER); // Center alignment for elements
        root.getChildren().addAll(label, okButton);


        Scene scene = new Scene(root, 300, 200);
        stage.setScene(scene);
        stage.setTitle("Exception Occurred");
        stage.show();
    }
}

