package application;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class MedicineDetailsController {

    @FXML
    private AnchorPane background;

//    @FXML
//    private Button back;

    private Stage stage;
    private Scene scene;
    private Parent root;
    private String[] modified;
    int ylayout ;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    
    @FXML
    void initialize(String []details) throws MalformedURLException {
    	
        Pane pane = new Pane();
        Button back =new Button("⬅");
        back.setPrefHeight(68);
        back.setPrefWidth(68);
        back.setLayoutX(0);
        back.setLayoutY(0);
        back.setStyle("-fx-background-color: rgba(10, 69, 44, 1);-fx-font-size: 24px;");
        back.setTextFill(Color.WHITE); 
        back.setOnAction(event->{
			try {
				back(event);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
        pane.getChildren().add(back);
        URL imageUrl = new URL("https://onemg.gumlet.io/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto," + details[11]);
        pane.setPrefSize(1500, 800);
        pane.setStyle("-fx-background-color: #EEEEEE;");
        executor.submit(() -> {
            try (InputStream stream = imageUrl.openStream()) {
                Image image = new Image(stream);

                Platform.runLater(() -> {
                    ImageView imageView = new ImageView(image);
                    imageView.setFitWidth(250);
                    imageView.setFitHeight(300);
                    imageView.setLayoutX(650);
                    imageView.setLayoutY(20);
                    pane.getChildren().add(imageView);
                });
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        int counter = 0;
        ylayout = 340;
        for (String i : details) {
            if (counter < 4 || counter > 11) {
                Label label = new Label();
                label.setPrefWidth(1500);
                label.setAlignment(Pos.CENTER);
                label.setLayoutY(ylayout);
                ylayout+=20;
                if(counter==0)
                {
                	label.setText("MedicineName: "+i);
                }
                else if(counter==1)
                {
                	label.setText("Composition: "+i);
                }
                else if(counter==2)
                {
                	label.setText("Uses: "+i);
                }else if(counter==3)
                {
                	label.setText("SideEffects: "+i);
                }else if(counter==12)
                {
                	label.setText("Manufacturer: "+i);
                }else if(counter==13)
                {
                	label.setText("Poor Ratings:"+i);
                }
                else if(counter==14)
                {
                	label.setText("Average Ratings:"+i);
                }
                else if(counter==15)
                {
                	label.setText("Low Ratings:"+i);
                }
                else if(counter==16)
                {
                	label.setText("Price £"+String.format("%.2f", Double.parseDouble(i)));
                }else if(counter==17)
                {
                	label.setText("Quantity: "+i);
                }
                else if(counter==18)
                {
                	label.setText("Expiry Date: "+i);
                }
                pane.getChildren().add(label);
            }
            counter++;
        }
        int xlayout = 550;
        Button addtocart = new Button("Add To Cart");
    	addtocart.setStyle("-fx-text-fill: white; -fx-background-color: #156543;");
        addtocart.setLayoutY(ylayout+20);
        addtocart.setLayoutX(xlayout+55);
       
        addtocart.setPrefWidth(100);
        
        addtocart.setOnAction(event -> {
//        System.out.println(details[17]);
        String quan="1";
        if(Integer.parseInt(details[17])>0)
        {

           File cart=new File("addtocart.csv");
           if(cart.exists()==false)
           {
        	   try {
				CSVWriter.createCSV("addtocart.csv",Main.username,details[0],details[12], String.format("%.2f", Double.parseDouble(details[16])),details[11],details[18]);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
           }
           else {
        	   try {
				Scanner cartread= new Scanner(cart);
				boolean exists=false;
				while(cartread.hasNextLine())
				{
					String itemsDetails=cartread.nextLine();
					String[] item=itemsDetails.split(",");
					if(item[0].equals(Main.username) && item[1].equals(details[0]))
					{
						quan=item[3];
						exists=true;
					}
				}
				if(exists==false)
					CSVWriter.addDetails("addtocart.csv",Main.username,details[0],details[12],String.format("%.2f", Double.parseDouble(details[16])),details[11],details[18]);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
           }
           addtocart.setVisible(false);
           TextField quantity = new TextField(quan);
           quantity.setDisable(true);
           quantity.setLayoutY(ylayout+20);
	       quantity.setLayoutX(xlayout+55);
	       quantity.prefWidth(100);
	       quantity.setAlignment(Pos.CENTER);
	       quantity.setStyle("-fx-background-color:white;-fx-text-fill:Black;");
           Button add= new Button("+");
           add.setLayoutY(ylayout+20);
           add.setLayoutX(xlayout+175);
           add.setStyle("-fx-background-color:#0A452C;-fx-text-fill:White;");
		      
           Button remove= new Button("-");
           remove.setLayoutY(ylayout+20);
           remove.setLayoutX(xlayout+55);
           remove.setStyle("-fx-background-color:#0A452C;-fx-text-fill:White;");
		      
//           add.prefWidth();
           
           add.setOnAction(addevent->{
        	   List<String[]> lines = new ArrayList<>();
        	   try {
				BufferedReader br = new BufferedReader(new FileReader("addtocart.csv"));
				String line;
	            while ((line = br.readLine()) != null) {
	                String[] data = line.split(",");
	                lines.add(data);
//	                System.out.println(line);
	            }
//	            System.out.println(details[0]);
	            for (String[] i : lines) {
	            	if(i[1].equals(details[0]) && i[0].equals(i[0]))
	            	{
	            		i[3]= String.valueOf(Integer.parseInt(i[3])+1);
	            		quantity.setText(i[3]);
	            	}
	            }
	            
	            writeCSV(lines);
	            
	        } catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	   
           });
           
           remove.setOnAction(addevent->{
        	   List<String[]> lines = new ArrayList<>();
        	   try {
				BufferedReader br = new BufferedReader(new FileReader("addtocart.csv"));
				String line;
				while ((line = br.readLine()) != null) {
	                String[] data = line.split(",");
	                lines.add(data);
	            }
				int printing=1;
//	            System.out.println(details[0]);
	            for (String[] i : lines) {
	            	if(i[1].equals(details[0]) && i[0].equals(i[0]))
	            	{
//	            		System.out.println(i);
	            		i[3]= String.valueOf(Integer.parseInt(i[3])-1);
	            		quantity.setText(i[3]);
	            		if(Integer.parseInt(i[3])==0)
	            		{
	            			add.setVisible(false);
	            			remove.setVisible(false);
	            			quantity.setVisible(false);
	            			addtocart.setVisible(true);
	            			CSVWriter.removeDetails("addtocart.csv", details[0], details);
	            			printing=0;
	            		}
	            	}
	            }
	            if(printing==1)
	            writeCSV(lines);
	            
	        } catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	   
           });
           pane.getChildren().add(quantity);
           pane.getChildren().add(add);
           pane.getChildren().add(remove);
           
        }});
       
    	pane.getChildren().add(addtocart);
        background.getChildren().add(pane);
    }

protected static void writeCSV(List<String[]> lines )
{
    try (BufferedWriter bw = new BufferedWriter(new FileWriter("addtocart.csv"))) {
//    	System.out.println(2);
    	for (String[] line : lines) {
            for (int i = 0; i < line.length; i++) {
                bw.write(line[i]);
                if (i < line.length - 1) {
                    bw.write(","); 
                }
            }
            bw.newLine(); 
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}


    @FXML
    private void back(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Main.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
