package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class SignUPController extends Exception{
	@FXML
	private TextField FullName;
	@FXML
	private TextField userName;
	@FXML
	private PasswordField PasswordText;
	@FXML
	private PasswordField ConfirmPassword;
	@FXML
	private CheckBox StaffCheck;
	@FXML
	private Button signUP;
	@FXML
	private Button logIN;
	private Parent root;
	private Stage stage;
	private Scene scene;
	
	public void logIN(ActionEvent event) throws IOException 
	{
		root =FXMLLoader.load(getClass().getResource("LogIN.fxml"));
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public  void signUP(ActionEvent event) throws IOException 
	{
		try 
		{
			List<String> lines = new ArrayList<>();
//			String namePattern = "^[A-Z][a-z]*(?: [A-Z][a-z]*)?(?:'?[A-Z][a-z]*)?(?:-[A-Z][a-z]*)?$";

//	        Pattern name= Pattern.compile(namePattern);
//	        Matcher matcher = name.matcher(userName.getText());
//	        if(!matcher.matches())
//	        {
//	        	throw new CustomException("Enter a valid FullName");
//	        }
//	        
	        if(FullName.getText().equals("") || userName.getText().equals("") || PasswordText.getText().equals("") || ConfirmPassword.getText().equals("") )
			{
					throw new CustomException("Fields Cannot be Empty");
			}
			else if(!PasswordText.getText().equals(ConfirmPassword.getText()))
			{
				throw new CustomException("Password and Confirm Password must Match");
			}
			else {
				File f = new File("userDetails.csv");
				if (f.exists()) {
				    FileReader fr = new FileReader("userDetails.csv");
				    BufferedReader br = new BufferedReader(fr);
				    String line;
				    while ((line = br.readLine()) != null) {
				        String[] part = line.split(",");
				        if (userName.getText().equals(part[1])) {
				            br.close();
				            throw new CustomException("UserName Already Exists");
				        }
				        lines.add(line);
				    }
				    br.close();

				    FileWriter fw = new FileWriter("userDetails.csv");
				    BufferedWriter bw = new BufferedWriter(fw);
				    for (String temp : lines) {
				        bw.write(temp); // Write the entire line to the file

				        // Add a new line after each line
				        bw.newLine();
				    }

				    boolean checkbox = StaffCheck.isSelected();
				    String staff = checkbox ? "true" : "false";
				    // Append the new user details to the file
				    bw.write(FullName.getText() + "," + userName.getText() + "," + PasswordText.getText() + "," + staff);
				    // Add a new line character to separate the newly added line
				    bw.newLine();
				    Main.username=userName.getText();
				    bw.close();
				}else {
					
					FileWriter fw = new FileWriter("userDetails.csv");
					BufferedWriter bw = new BufferedWriter(fw);
					bw.write("FullName"+","+"userName"+","+"PasswordText"+","+"StaffCheck"+"\n");
					
					boolean checkbox=StaffCheck.isSelected();
					String staff = checkbox?"true" : "false";
					bw.write(FullName.getText()+","+userName.getText()+","+PasswordText.getText()+","+staff+"\n");
					bw.close();
				}
				if(!StaffCheck.isSelected())
				{
					root =FXMLLoader.load(getClass().getResource("Main.fxml"));	
					stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
					scene = new Scene(root);
					stage.setScene(scene);
					stage.show();
				}
				else {
					root =FXMLLoader.load(getClass().getResource("PharmacyManagement.fxml"));	
					stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
					scene = new Scene(root);
					stage.setScene(scene);
					stage.show();
				}
			}
			
		}catch (CustomException e) {
            ExceptionHandler.handleException(e);
        }
		
	}
	

	

	
}
